# funConcertFinder
An Alexa Skill for the Amazon Echo that helps users determine concert dates and venues by artist.
